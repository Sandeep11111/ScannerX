package nycschools.viewmodel;

import android.arch.lifecycle.Lifecycle;
import android.arch.lifecycle.LifecycleObserver;
import android.arch.lifecycle.OnLifecycleEvent;
import android.databinding.ObservableField;

import javax.inject.Inject;

public class MainViewModel implements LifecycleObserver {

    public final ObservableField<String> testText = new ObservableField<>();

    @Inject
    public MainViewModel() {
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    public void onResume() {
        testText.set("test viewmodel");
    }
}
