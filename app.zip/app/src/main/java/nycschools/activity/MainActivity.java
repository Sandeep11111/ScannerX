package nycschools.activity;

import android.support.v7.app.AppCompatActivity;

import javax.inject.Inject;

import nycschools.viewmodel.MainViewModel;

public class MainActivity extends AppCompatActivity {

    @Inject
    MainViewModel mainViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_blanco_education);
        viewModel.setViewCallbackEmitter(getViewCallbackEmitter());
        binding.setViewModel(viewModel);
    }
}
